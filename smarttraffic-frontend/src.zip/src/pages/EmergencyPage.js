import { useState } from 'react';
import { FiAlertTriangle, FiMap, FiNavigation, FiPlay } from 'react-icons/fi';

const EmergencyPage = () => {
  const [activeEmergency, setActiveEmergency] = useState(0);

  const emergencies = [
    {
      id: 1,
      type: 'Ambulance',
      priority: 'High',
      location: 'Junction J-03 - Main St & 5th Ave',
      time: '2 minutes ago',
      eta: '3 minutes',
      status: 'In Progress',
      vehicleId: 'AMB-7281',
      destination: 'City General Hospital'
    },
    {
      id: 2,
      type: 'Fire Truck',
      priority: 'Critical',
      location: 'Junction J-07 - River Road & Park Lane',
      time: '5 minutes ago',
      eta: '2 minutes',
      status: 'Route Clearing',
      vehicleId: 'FR-4512',
      destination: 'Central Fire Station'
    },
    {
      id: 3,
      type: 'Police Car',
      priority: 'Medium',
      location: 'Junction J-12 - Highway 5 Entrance',
      time: '8 minutes ago',
      eta: '1 minute',
      status: 'Almost Cleared',
      vehicleId: 'PD-8934',
      destination: 'Downtown Precinct'
    }
  ];

  const hospitals = [
    { name: 'City General Hospital', distance: '2.1 km', beds: 45 },
    { name: 'Central Medical Center', distance: '3.4 km', beds: 23 },
    { name: 'Unity Hospital', distance: '4.2 km', beds: 67 }
  ];

  return (
    <div className="fade-in">
      <div className="emergency-grid">
        {/* Emergency List */}
        <div className="emergency-list">
          <div className="card-header">
            <h3 className="card-title">
              <FiAlertTriangle style={{marginRight: '0.5rem'}} />
              Active Emergencies
            </h3>
            <div className="emergency-indicator">
              {emergencies.length} Active
            </div>
          </div>

          {emergencies.map((emergency, index) => (
            <div 
              key={emergency.id}
              className="emergency-item"
              style={{
                background: index === activeEmergency ? 'rgba(37, 99, 235, 0.1)' : 'rgba(220, 38, 38, 0.1)',
                borderLeftColor: index === activeEmergency ? 'var(--primary)' : 'var(--danger)',
                cursor: 'pointer'
              }}
              onClick={() => setActiveEmergency(index)}
            >
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: index === activeEmergency ? 'var(--primary)' : 'var(--danger)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                flexShrink: 0
              }}>
                {emergency.type === 'Ambulance' ? '🚑' : 
                 emergency.type === 'Fire Truck' ? '🚒' : '🚓'}
              </div>
              
              <div style={{flex: 1}}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '1rem',
                  marginBottom: '0.5rem'
                }}>
                  <h4 style={{color: 'var(--text-primary)', fontSize: '1.1rem'}}>
                    {emergency.type} - {emergency.vehicleId}
                  </h4>
                  <span style={{
                    padding: '0.25rem 0.75rem',
                    background: emergency.priority === 'Critical' ? 'var(--danger)' : 
                                emergency.priority === 'High' ? 'var(--warning)' : 'var(--accent)',
                    color: 'white',
                    borderRadius: '12px',
                    fontSize: '0.75rem',
                    fontWeight: '600'
                  }}>
                    {emergency.priority}
                  </span>
                </div>
                
                <p style={{color: 'var(--text-secondary)', marginBottom: '0.25rem'}}>
                  📍 {emergency.location}
                </p>
                
                <div style={{
                  display: 'flex',
                  gap: '1rem',
                  fontSize: '0.875rem',
                  color: 'var(--text-secondary)'
                }}>
                  <span>🕒 {emergency.time}</span>
                  <span>⏱️ ETA: {emergency.eta}</span>
                </div>
              </div>
              
              <div style={{
                textAlign: 'right'
              }}>
                <div style={{
                  padding: '0.5rem 1rem',
                  background: 'var(--success)',
                  color: 'white',
                  borderRadius: '6px',
                  fontSize: '0.875rem',
                  fontWeight: '600',
                  marginBottom: '0.5rem'
                }}>
                  {emergency.status}
                </div>
                <button className="btn btn-primary" style={{padding: '0.5rem 1rem'}}>
                  <FiPlay />
                  Track
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Emergency Map & Details */}
        <div style={{display: 'flex', flexDirection: 'column', gap: '1.5rem'}}>
          {/* Map View */}
          <div className="emergency-map">
            <div style={{
              width: '100%',
              height: '100%',
              background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)',
              borderRadius: '8px',
              position: 'relative',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              {/* Simplified Map */}
              <div style={{
                width: '80%',
                height: '80%',
                background: 'var(--bg-primary)',
                borderRadius: '8px',
                position: 'relative',
                border: '2px solid var(--border)'
              }}>
                {/* Roads */}
                <div style={{
                  position: 'absolute',
                  top: '50%',
                  left: '0',
                  width: '100%',
                  height: '4px',
                  background: '#64748b',
                  transform: 'translateY(-50%)'
                }}></div>
                
                <div style={{
                  position: 'absolute',
                  top: '0',
                  left: '50%',
                  width: '4px',
                  height: '100%',
                  background: '#64748b',
                  transform: 'translateX(-50%)'
                }}></div>

                {/* Emergency Vehicle */}
                <div style={{
                  position: 'absolute',
                  top: '48%',
                  left: '30%',
                  width: '20px',
                  height: '10px',
                  background: 'var(--danger)',
                  borderRadius: '2px',
                  animation: 'pulse 1s infinite'
                }}></div>

                {/* Route to Hospital */}
                <div style={{
                  position: 'absolute',
                  top: '48%',
                  left: '30%',
                  width: '40%',
                  height: '2px',
                  background: 'var(--primary)',
                  transform: 'rotate(-15deg)',
                  transformOrigin: 'left center'
                }}></div>

                {/* Hospital */}
                <div style={{
                  position: 'absolute',
                  top: '30%',
                  left: '70%',
                  width: '15px',
                  height: '15px',
                  background: 'var(--success)',
                  borderRadius: '50%'
                }}></div>

                <div style={{
                  position: 'absolute',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  textAlign: 'center',
                  color: 'var(--text-secondary)'
                }}>
                  <FiMap size={48} style={{marginBottom: '1rem', opacity: 0.5}} />
                  <div>Live Emergency Tracking</div>
                  <div style={{fontSize: '0.875rem', marginTop: '0.5rem'}}>
                    {emergencies[activeEmergency]?.type} en route
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Hospital Information */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">
                <FiNavigation style={{marginRight: '0.5rem'}} />
                Nearby Hospitals
              </h3>
            </div>
            
            <div>
              {hospitals.map((hospital, index) => (
                <div key={index} style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '1rem',
                  borderBottom: '1px solid var(--border)'
                }}>
                  <div>
                    <div style={{
                      fontWeight: '600',
                      color: 'var(--text-primary)',
                      marginBottom: '0.25rem'
                    }}>
                      {hospital.name}
                    </div>
                    <div style={{
                      fontSize: '0.875rem',
                      color: 'var(--text-secondary)'
                    }}>
                      📍 {hospital.distance} away
                    </div>
                  </div>
                  
                  <div style={{textAlign: 'right'}}>
                    <div style={{
                      fontSize: '0.875rem',
                      color: 'var(--text-secondary)',
                      marginBottom: '0.25rem'
                    }}>
                      {hospital.beds} beds available
                    </div>
                    <button className="btn btn-primary" style={{padding: '0.5rem 1rem'}}>
                      Set Route
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Emergency Controls */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Emergency Response</h3>
            </div>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '1rem'
            }}>
              <button className="btn btn-success">
                Clear Route
              </button>
              <button className="btn btn-secondary">
                Notify Authorities
              </button>
              <button className="btn btn-primary">
                Optimize Traffic
              </button>
              <button className="btn btn-danger">
                Manual Override
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmergencyPage;