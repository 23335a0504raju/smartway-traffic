import { FiAward, FiBook, FiGithub, FiUsers } from 'react-icons/fi';

const AboutPage = () => {
  const teamMembers = [
    { name: 'Alex Chen', role: 'AI Engineer', initial: 'A' },
    { name: 'Sarah Johnson', role: 'System Architect', initial: 'S' },
    { name: 'Mike Rodriguez', role: 'Frontend Developer', initial: 'M' },
    { name: 'Emily Zhang', role: 'Data Scientist', initial: 'E' },
  ];

  return (
    <div className="about-container fade-in">
      {/* Hero Section */}
      <div className="about-section">
        <h1>About TrafficAI</h1>
        <p>
          TrafficAI is an intelligent traffic management system that leverages cutting-edge 
          artificial intelligence to optimize urban mobility, reduce congestion, and 
          prioritize emergency response vehicles.
        </p>
        <p>
          Our mission is to create smarter, safer, and more efficient cities through 
          innovative technology that adapts to real-time traffic conditions and 
          emergency situations.
        </p>
      </div>

      {/* Features Overview */}
      <div className="about-section">
        <h2>System Features</h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '1.5rem',
          marginTop: '1.5rem'
        }}>
          <div className="feature-card">
            <h3>🤖 AI-Powered Optimization</h3>
            <p>Real-time traffic flow analysis and adaptive signal control using machine learning algorithms.</p>
          </div>
          
          <div className="feature-card">
            <h3>🚑 Emergency Priority</h3>
            <p>Automatic detection and route clearing for emergency vehicles to ensure fastest response times.</p>
          </div>
          
          <div className="feature-card">
            <h3>📊 Live Analytics</h3>
            <p>Comprehensive monitoring and reporting system for traffic performance and system efficiency.</p>
          </div>
          
          <div className="feature-card">
            <h3>🔧 Simulation Environment</h3>
            <p>Test and optimize traffic management strategies in a controlled simulation environment.</p>
          </div>
        </div>
      </div>

      {/* Technology Stack */}
      <div className="about-section">
        <h2>Technology Stack</h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem',
          marginTop: '1.5rem'
        }}>
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '1rem',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <div style={{fontWeight: '600', marginBottom: '0.5rem'}}>Frontend</div>
            <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
              React, Recharts, CSS3
            </div>
          </div>
          
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '1rem',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <div style={{fontWeight: '600', marginBottom: '0.5rem'}}>AI/ML</div>
            <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
              TensorFlow, OpenCV, YOLO
            </div>
          </div>
          
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '1rem',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <div style={{fontWeight: '600', marginBottom: '0.5rem'}}>Backend</div>
            <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
              Node.js, Python, PostgreSQL
            </div>
          </div>
          
          <div style={{
            background: 'var(--bg-secondary)',
            padding: '1rem',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <div style={{fontWeight: '600', marginBottom: '0.5rem'}}>Infrastructure</div>
            <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
              AWS, Docker, Redis
            </div>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="about-section">
        <h2>Our Team</h2>
        <p>
          We're a passionate team of engineers, data scientists, and urban planners 
          dedicated to solving complex traffic challenges through technology.
        </p>
        
        <div className="team-grid">
          {teamMembers.map((member, index) => (
            <div key={index} className="team-member">
              <div className="member-avatar">
                {member.initial}
              </div>
              <h4 style={{marginBottom: '0.5rem'}}>{member.name}</h4>
              <p style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                {member.role}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Documentation Links */}
      <div className="about-section">
        <h2>Documentation & Resources</h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '1rem',
          marginTop: '1.5rem'
        }}>
          <a href="#" style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            padding: '1rem',
            background: 'var(--bg-secondary)',
            borderRadius: '8px',
            textDecoration: 'none',
            color: 'var(--text-primary)',
            transition: 'all 0.3s ease'
          }}>
            <FiBook size={24} />
            <div>
              <div style={{fontWeight: '600'}}>User Guide</div>
              <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                Complete system documentation
              </div>
            </div>
          </a>
          
          <a href="#" style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            padding: '1rem',
            background: 'var(--bg-secondary)',
            borderRadius: '8px',
            textDecoration: 'none',
            color: 'var(--text-primary)',
            transition: 'all 0.3s ease'
          }}>
            <FiGithub size={24} />
            <div>
              <div style={{fontWeight: '600'}}>GitHub Repository</div>
              <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                Source code and contributions
              </div>
            </div>
          </a>
          
          <a href="#" style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            padding: '1rem',
            background: 'var(--bg-secondary)',
            borderRadius: '8px',
            textDecoration: 'none',
            color: 'var(--text-primary)',
            transition: 'all 0.3s ease'
          }}>
            <FiUsers size={24} />
            <div>
              <div style={{fontWeight: '600'}}>API Documentation</div>
              <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                Integration guides and references
              </div>
            </div>
          </a>
          
          <a href="#" style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            padding: '1rem',
            background: 'var(--bg-secondary)',
            borderRadius: '8px',
            textDecoration: 'none',
            color: 'var(--text-primary)',
            transition: 'all 0.3s ease'
          }}>
            <FiAward size={24} />
            <div>
              <div style={{fontWeight: '600'}}>Case Studies</div>
              <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                Real-world implementations
              </div>
            </div>
          </a>
        </div>
      </div>

      {/* Contact Information */}
      <div className="about-section">
        <h2>Contact & Support</h2>
        <p>
          For technical support, feature requests, or partnership inquiries, 
          please reach out to our team.
        </p>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '1rem',
          marginTop: '1.5rem'
        }}>
          <div>
            <h4 style={{marginBottom: '0.5rem'}}>Email</h4>
            <p style={{color: 'var(--text-secondary)'}}>support@trafficai.com</p>
          </div>
          
          <div>
            <h4 style={{marginBottom: '0.5rem'}}>Phone</h4>
            <p style={{color: 'var(--text-secondary)'}}>+1 (555) 123-4567</p>
          </div>
          
          <div>
            <h4 style={{marginBottom: '0.5rem'}}>Office</h4>
            <p style={{color: 'var(--text-secondary)'}}>
              123 Innovation Drive<br />
              Tech City, TC 12345
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;