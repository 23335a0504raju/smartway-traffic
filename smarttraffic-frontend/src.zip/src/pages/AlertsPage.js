import { useState } from 'react';
import { FiAlertTriangle, FiCheck, FiDownload, FiFilter, FiInfo } from 'react-icons/fi';

const AlertsPage = () => {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const alerts = [
    {
      id: 1,
      type: 'Emergency',
      severity: 'critical',
      location: 'Junction J-03',
      description: 'Ambulance detected - Route optimization activated',
      time: '2024-01-15 14:23:45',
      status: 'active'
    },
    {
      id: 2,
      type: 'Congestion',
      severity: 'high',
      location: 'Junction J-07',
      description: 'Heavy traffic detected - AI adjusting light timings',
      time: '2024-01-15 13:45:12',
      status: 'resolved'
    },
    {
      id: 3,
      type: 'System',
      severity: 'medium',
      location: 'Camera CAM-012',
      description: 'Camera feed temporarily unavailable',
      time: '2024-01-15 12:30:33',
      status: 'pending'
    },
    {
      id: 4,
      type: 'Emergency',
      severity: 'critical',
      location: 'Junction J-12',
      description: 'Fire truck priority route established',
      time: '2024-01-15 11:15:22',
      status: 'resolved'
    },
    {
      id: 5,
      type: 'Maintenance',
      severity: 'low',
      location: 'System Wide',
      description: 'Scheduled maintenance completed',
      time: '2024-01-15 10:05:18',
      status: 'resolved'
    }
  ];

  const filteredAlerts = alerts.filter(alert => {
    const matchesFilter = filter === 'all' || alert.status === filter;
    const matchesSearch = alert.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         alert.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return <FiAlertTriangle style={{color: 'var(--danger)'}} />;
      case 'high': return <FiAlertTriangle style={{color: 'var(--warning)'}} />;
      case 'medium': return <FiInfo style={{color: 'var(--accent)'}} />;
      case 'low': return <FiInfo style={{color: 'var(--primary)'}} />;
      default: return <FiInfo />;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active': return 'status-active';
      case 'resolved': return 'status-resolved';
      case 'pending': return 'status-pending';
      default: return '';
    }
  };

  return (
    <div className="alerts-container fade-in">
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '2rem'
      }}>
        <h1 style={{fontSize: '2rem', fontWeight: '700'}}>Alerts & Notifications</h1>
        <button className="btn btn-primary">
          <FiDownload />
          Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="alerts-filters">
        <input
          type="text"
          placeholder="Search alerts..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="filter-select"
          style={{flex: 1}}
        />
        
        <select 
          className="filter-select"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="pending">Pending</option>
          <option value="resolved">Resolved</option>
        </select>
        
        <select className="filter-select">
          <option value="all">All Types</option>
          <option value="emergency">Emergency</option>
          <option value="congestion">Congestion</option>
          <option value="system">System</option>
          <option value="maintenance">Maintenance</option>
        </select>
        
        <select className="filter-select">
          <option value="all">All Severity</option>
          <option value="critical">Critical</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
      </div>

      {/* Alerts Table */}
      <div className="alerts-table">
        {/* Table Header */}
        <div className="table-header">
          <div>Type & Severity</div>
          <div>Location</div>
          <div>Description</div>
          <div>Time</div>
          <div>Actions</div>
        </div>

        {/* Table Rows */}
        {filteredAlerts.map(alert => (
          <div key={alert.id} className="table-row">
            <div style={{display: 'flex', alignItems: 'center', gap: '0.5rem'}}>
              {getSeverityIcon(alert.severity)}
              <div>
                <div style={{fontWeight: '600'}}>{alert.type}</div>
                <div style={{
                  fontSize: '0.75rem',
                  color: 'var(--text-secondary)',
                  textTransform: 'capitalize'
                }}>
                  {alert.severity}
                </div>
              </div>
            </div>
            
            <div>
              <div style={{fontWeight: '600'}}>{alert.location}</div>
            </div>
            
            <div>
              <div>{alert.description}</div>
            </div>
            
            <div>
              <div style={{fontWeight: '600'}}>
                {new Date(alert.time).toLocaleDateString()}
              </div>
              <div style={{fontSize: '0.75rem', color: 'var(--text-secondary)'}}>
                {new Date(alert.time).toLocaleTimeString()}
              </div>
            </div>
            
            <div style={{display: 'flex', gap: '0.5rem', alignItems: 'center'}}>
              <span className={`status-badge ${getStatusBadge(alert.status)}`}>
                {alert.status}
              </span>
              {alert.status === 'active' && (
                <button 
                  className="btn btn-success"
                  style={{padding: '0.25rem 0.5rem'}}
                >
                  <FiCheck />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Summary Stats */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '1rem',
        marginTop: '2rem'
      }}>
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Total Alerts
          </div>
          <div className="stats-value">{alerts.length}</div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Active Alerts
          </div>
          <div className="stats-value">
            {alerts.filter(a => a.status === 'active').length}
          </div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Critical Alerts
          </div>
          <div className="stats-value">
            {alerts.filter(a => a.severity === 'critical').length}
          </div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Avg. Response Time
          </div>
          <div className="stats-value">2.3m</div>
        </div>
      </div>

      {/* Empty State */}
      {filteredAlerts.length === 0 && (
        <div style={{
          textAlign: 'center',
          padding: '4rem 2rem',
          color: 'var(--text-secondary)'
        }}>
          <FiFilter size={48} style={{marginBottom: '1rem', opacity: 0.5}} />
          <div style={{fontSize: '1.25rem', marginBottom: '0.5rem'}}>
            No alerts found
          </div>
          <div>Try adjusting your filters or search terms</div>
        </div>
      )}
    </div>
  );
};

export default AlertsPage;