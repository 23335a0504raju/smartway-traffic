import { FiAlertTriangle, FiCar, FiClock, FiTrendingUp } from 'react-icons/fi';
import StatsCard from '../components/Dashboard/StatsCard';
import { JunctionChart, TrafficFlowChart } from '../components/Dashboard/TrafficChart';

const DashboardPage = ({ aiMode }) => {
  const alerts = [
    {
      type: 'critical',
      title: 'Emergency Vehicle Detected',
      message: 'Ambulance approaching Junction J-03',
      time: '2 min ago'
    },
    {
      type: 'warning',
      title: 'High Traffic Congestion',
      message: 'Heavy traffic at Junction J-07',
      time: '5 min ago'
    },
    {
      type: 'info',
      title: 'System Update',
      message: 'AI models updated successfully',
      time: '10 min ago'
    }
  ];

  return (
    <div className="dashboard fade-in">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Traffic Dashboard</h1>
        <div style={{
          padding: '0.5rem 1rem',
          background: aiMode ? 'var(--success)' : 'var(--warning)',
          color: 'white',
          borderRadius: '20px',
          fontSize: '0.875rem',
          fontWeight: '600'
        }}>
          {aiMode ? '🤖 AI Mode Active' : '👤 Manual Control'}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-grid">
        <StatsCard
          title="Total Vehicles Tracked"
          value="1,247"
          change={12}
          icon={<FiCar />}
          color="primary"
        />
        <StatsCard
          title="Active Emergencies"
          value="3"
          change={-5}
          icon={<FiAlertTriangle />}
          color="danger"
        />
        <StatsCard
          title="Avg. Traffic Flow"
          value="78%"
          change={8}
          icon={<FiTrendingUp />}
          color="success"
        />
        <StatsCard
          title="Avg. Wait Time"
          value="45s"
          change={-15}
          icon={<FiClock />}
          color="accent"
        />
      </div>

      {/* Charts Grid */}
      <div className="charts-grid">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Traffic Flow & Congestion</h3>
          </div>
          <TrafficFlowChart />
        </div>
        
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Junction Performance</h3>
          </div>
          <JunctionChart />
        </div>
      </div>

      {/* Alerts Panel */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Recent Alerts</h3>
        </div>
        <div className="alerts-panel">
          {alerts.map((alert, index) => (
            <div key={index} className="alert-item">
              <div className={`alert-icon ${alert.type}`}>
                <FiAlertTriangle />
              </div>
              <div className="alert-content">
                <div className="alert-title">{alert.title}</div>
                <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
                  {alert.message}
                </div>
              </div>
              <div className="alert-time">{alert.time}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;