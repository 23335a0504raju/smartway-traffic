import { useEffect, useState } from 'react';
import { FiPause, FiPlay, FiRefreshCw, FiSettings, FiSquare } from 'react-icons/fi';

const SimulationPage = () => {
  const [simulationState, setSimulationState] = useState('stopped'); // stopped, running, paused
  const [trafficDensity, setTrafficDensity] = useState(50);
  const [emergencyFrequency, setEmergencyFrequency] = useState(30);
  const [simulationTime, setSimulationTime] = useState(0);

  useEffect(() => {
    let interval;
    if (simulationState === 'running') {
      interval = setInterval(() => {
        setSimulationTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [simulationState]);

  const resetSimulation = () => {
    setSimulationState('stopped');
    setSimulationTime(0);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="simulation-container fade-in">
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '2rem'
      }}>
        <h1 style={{fontSize: '2rem', fontWeight: '700'}}>Traffic Simulation</h1>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '1rem',
          background: 'var(--bg-card)',
          padding: '0.75rem 1.5rem',
          borderRadius: '12px',
          border: '1px solid var(--border)'
        }}>
          <div style={{fontSize: '0.875rem', color: 'var(--text-secondary)'}}>
            Simulation Time:
          </div>
          <div style={{fontSize: '1.25rem', fontWeight: '600', color: 'var(--primary)'}}>
            {formatTime(simulationTime)}
          </div>
        </div>
      </div>

      {/* Simulation View */}
      <div className="simulation-view">
        <div style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
          borderRadius: '8px',
          position: 'relative',
          overflow: 'hidden'
        }}>
          {/* Road Network Simulation */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '0',
            width: '100%',
            height: '4px',
            background: '#64748b',
            transform: 'translateY(-50%)'
          }}></div>
          
          <div style={{
            position: 'absolute',
            top: '0',
            left: '50%',
            width: '4px',
            height: '100%',
            background: '#64748b',
            transform: 'translateX(-50%)'
          }}></div>

          {/* Traffic Lights */}
          <div style={{
            position: 'absolute',
            top: '45%',
            left: '48%',
            display: 'flex',
            gap: '4px'
          }}>
            {['red', 'yellow', 'green'].map((color, index) => (
              <div
                key={color}
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  background: index === 2 ? '#16a34a' : '#475569',
                  boxShadow: index === 2 ? '0 0 10px #16a34a' : 'none'
                }}
              ></div>
            ))}
          </div>

          {/* Moving Vehicles */}
          {simulationState === 'running' && (
            <>
              <div style={{
                position: 'absolute',
                top: '48%',
                left: `${(simulationTime * 2) % 100}%`,
                width: '20px',
                height: '10px',
                background: '#3b82f6',
                borderRadius: '2px',
                transition: 'left 0.1s linear'
              }}></div>
              
              <div style={{
                position: 'absolute',
                top: '52%',
                left: `${100 - ((simulationTime * 3) % 100)}%`,
                width: '25px',
                height: '12px',
                background: '#ef4444',
                borderRadius: '2px',
                transition: 'left 0.1s linear'
              }}></div>

              {/* Emergency Vehicle */}
              {(simulationTime % 20 === 5) && (
                <div style={{
                  position: 'absolute',
                  top: '46%',
                  left: `${(simulationTime * 5) % 100}%`,
                  width: '30px',
                  height: '15px',
                  background: '#dc2626',
                  borderRadius: '2px',
                  transition: 'left 0.1s linear',
                  animation: 'pulse 0.5s infinite'
                }}></div>
              )}
            </>
          )}

          {/* Simulation Status */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            textAlign: 'center',
            color: 'var(--text-secondary)'
          }}>
            <div style={{fontSize: '4rem', marginBottom: '1rem'}}>
              {simulationState === 'running' ? '🚦' : 
               simulationState === 'paused' ? '⏸️' : '🛑'}
            </div>
            <div style={{fontSize: '1.5rem', fontWeight: '600'}}>
              {simulationState === 'running' ? 'Simulation Running' : 
               simulationState === 'paused' ? 'Simulation Paused' : 'Simulation Stopped'}
            </div>
            <div style={{marginTop: '0.5rem'}}>
              {simulationState === 'stopped' && 'Click Start to begin simulation'}
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div style={{
        display: 'flex',
        gap: '1rem',
        marginBottom: '2rem',
        justifyContent: 'center'
      }}>
        <button 
          className={`btn ${simulationState === 'running' ? 'btn-secondary' : 'btn-primary'}`}
          onClick={() => setSimulationState('running')}
          disabled={simulationState === 'running'}
        >
          <FiPlay />
          Start
        </button>
        
        <button 
          className="btn btn-secondary"
          onClick={() => setSimulationState('paused')}
          disabled={simulationState !== 'running'}
        >
          <FiPause />
          Pause
        </button>
        
        <button 
          className="btn btn-danger"
          onClick={resetSimulation}
        >
          <FiSquare />
          Stop
        </button>
        
        <button 
          className="btn btn-secondary"
          onClick={resetSimulation}
        >
          <FiRefreshCw />
          Reset
        </button>
      </div>

      {/* Control Panel */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">
            <FiSettings style={{marginRight: '0.5rem'}} />
            Simulation Parameters
          </h3>
        </div>
        
        <div className="controls-panel">
          <div>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: 'var(--text-secondary)',
              fontWeight: '500'
            }}>
              Traffic Density: {trafficDensity}%
            </label>
            <input
              type="range"
              min="10"
              max="100"
              value={trafficDensity}
              onChange={(e) => setTrafficDensity(e.target.value)}
              style={{width: '100%'}}
              disabled={simulationState === 'running'}
            />
          </div>
          
          <div>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: 'var(--text-secondary)',
              fontWeight: '500'
            }}>
              Emergency Frequency: {emergencyFrequency}%
            </label>
            <input
              type="range"
              min="5"
              max="100"
              value={emergencyFrequency}
              onChange={(e) => setEmergencyFrequency(e.target.value)}
              style={{width: '100%'}}
              disabled={simulationState === 'running'}
            />
          </div>
          
          <div>
            <label style={{
              display: 'block',
              marginBottom: '0.5rem',
              color: 'var(--text-secondary)',
              fontWeight: '500'
            }}>
              AI Control Mode
            </label>
            <select 
              className="filter-select" 
              style={{width: '100%'}}
              disabled={simulationState === 'running'}
            >
              <option>Adaptive AI</option>
              <option>Fixed Timing</option>
              <option>Manual Control</option>
            </select>
          </div>
        </div>
      </div>

      {/* Simulation Stats */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '1rem',
        marginTop: '2rem'
      }}>
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Vehicles Processed
          </div>
          <div className="stats-value">
            {Math.floor(simulationTime * trafficDensity / 10)}
          </div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Emergencies Handled
          </div>
          <div className="stats-value">
            {Math.floor(simulationTime * emergencyFrequency / 100)}
          </div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Avg. Wait Time
          </div>
          <div className="stats-value">
            {simulationTime > 0 ? '45s' : '0s'}
          </div>
        </div>
        
        <div className="stats-card">
          <div style={{color: 'var(--text-secondary)', fontSize: '0.875rem'}}>
            Efficiency
          </div>
          <div className="stats-value">
            {simulationTime > 0 ? '87%' : '0%'}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimulationPage;