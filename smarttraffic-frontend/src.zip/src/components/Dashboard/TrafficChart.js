import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

const trafficData = [
  { time: '00:00', vehicles: 45, congestion: 25 },
  { time: '04:00', vehicles: 32, congestion: 18 },
  { time: '08:00', vehicles: 89, congestion: 65 },
  { time: '12:00', vehicles: 76, congestion: 52 },
  { time: '16:00', vehicles: 94, congestion: 78 },
  { time: '20:00', vehicles: 67, congestion: 45 },
];

const junctionData = [
  { junction: 'J-01', vehicles: 245, efficiency: 85 },
  { junction: 'J-02', vehicles: 189, efficiency: 92 },
  { junction: 'J-03', vehicles: 312, efficiency: 78 },
  { junction: 'J-04', vehicles: 156, efficiency: 88 },
  { junction: 'J-05', vehicles: 278, efficiency: 82 },
];

export const TrafficFlowChart = () => (
  <ResponsiveContainer width="100%" height={300}>
    <LineChart data={trafficData}>
      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
      <XAxis dataKey="time" stroke="var(--text-secondary)" />
      <YAxis stroke="var(--text-secondary)" />
      <Tooltip 
        contentStyle={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
          borderRadius: '8px'
        }}
      />
      <Line type="monotone" dataKey="vehicles" stroke="var(--primary)" strokeWidth={2} />
      <Line type="monotone" dataKey="congestion" stroke="var(--accent)" strokeWidth={2} />
    </LineChart>
  </ResponsiveContainer>
);

export const JunctionChart = () => (
  <ResponsiveContainer width="100%" height={300}>
    <BarChart data={junctionData}>
      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
      <XAxis dataKey="junction" stroke="var(--text-secondary)" />
      <YAxis stroke="var(--text-secondary)" />
      <Tooltip 
        contentStyle={{
          background: 'var(--bg-card)',
          border: '1px solid var(--border)',
          borderRadius: '8px'
        }}
      />
      <Bar dataKey="vehicles" fill="var(--primary)" />
      <Bar dataKey="efficiency" fill="var(--success)" />
    </BarChart>
  </ResponsiveContainer>
);