import { FiActivity, FiMenu } from 'react-icons/fi';
import { Link, useLocation } from 'react-router-dom';

const Navbar = ({ onMenuToggle }) => {
  const location = useLocation();

  return (
    <nav className="navbar">
      <div className="navbar-content">
        <Link to="/" className="logo">
          <FiActivity className="logo-icon" />
          TrafficAI
        </Link>
        
        <div className="nav-links">
          <Link 
            to="/dashboard" 
            className={`nav-link ${location.pathname === '/dashboard' ? 'active' : ''}`}
          >
            Dashboard
          </Link>
          <Link 
            to="/cameras" 
            className={`nav-link ${location.pathname === '/cameras' ? 'active' : ''}`}
          >
            Cameras
          </Link>
          <Link 
            to="/simulation" 
            className={`nav-link ${location.pathname === '/simulation' ? 'active' : ''}`}
          >
            Simulation
          </Link>
          <Link 
            to="/emergency" 
            className={`nav-link ${location.pathname === '/emergency' ? 'active' : ''}`}
          >
            Emergency
          </Link>
        </div>
        
        <button className="menu-toggle" onClick={onMenuToggle}>
          <FiMenu />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;