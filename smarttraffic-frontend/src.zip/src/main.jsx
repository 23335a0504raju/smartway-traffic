import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import LiveCamera from "./pages/LiveCamera";
import Simulation from "./pages/Simulation";
import Emergency from "./pages/Emergency";
import Alerts from "./pages/Alerts";
import Analytics from "./pages/Analytics";
import About from "./pages/About";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/livecamera" element={<LiveCamera />} />
        <Route path="/simulation" element={<Simulation />} />
        <Route path="/emergency" element={<Emergency />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/about" element={<About />} />
      </Routes>
      <Footer />
    </Router>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
